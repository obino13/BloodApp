package com.example.bloodapplication;

import android.app.Fragment;

public class NationalFragment extends Fragment {
}
