package com.example.bloodapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Local extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local);
    }
}
