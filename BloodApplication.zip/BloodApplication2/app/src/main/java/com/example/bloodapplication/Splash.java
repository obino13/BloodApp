package com.example.bloodapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;

import com.felipecsl.gifimageview.library.GifImageView;

import org.apache.commons.io.IOUtils;

import java.io.InputStream;

public class Splash extends Activity {
    private GifImageView gifImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_splash);

//How to Hide the status and action bar
      /*  View decorView=getWindow().getDecorView();
        int uiOptions=View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
*/







        gifImageView= findViewById(R.id.gifimageview);


        try{
            InputStream inputStream=getAssets().open("gif1.gif");
            byte[] bytes= IOUtils.toByteArray(inputStream);
            gifImageView.setBytes(bytes);
            gifImageView.startAnimation();

        }catch(Exception e)
        {
            e.printStackTrace();

        }

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                com.example.bloodapplication.Splash.this.startActivity(new Intent(com.example.bloodapplication.Splash.this,MainActivity.class));
                com.example.bloodapplication.Splash.this.finish();
            }
        },3000);

    }




}
